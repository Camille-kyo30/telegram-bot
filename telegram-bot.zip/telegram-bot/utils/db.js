const fs = require("fs");
const path = require("path");

// Stockage JSON basique — suffisant pour démarrer, mais réinitialisé à
// chaque redéploiement sur Render (disque éphémère). Envisager MongoDB
// (comme pour senpai-stickers) si la persistance long terme devient importante.
const DB_PATH = path.join(__dirname, "..", "data", "db.json");

const DEFAULT_DB = {
  warns: {}, // { [chatId]: { [userId]: count } }
  badwords: {}, // { [chatId]: string[] }
  badwordsEnabled: {}, // { [chatId]: boolean }
  rules: {}, // { [chatId]: string }
  roles: {}, // { [chatId]: { [userId]: "admin"|"vip"|"member" } }
  adminOnly: {}, // { [chatId]: boolean }
};

function ensureDb() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2));
  }
}

function readDb() {
  ensureDb();
  const raw = JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
  return { ...DEFAULT_DB, ...raw };
}

function writeDb(data) {
  ensureDb();
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = { readDb, writeDb };
