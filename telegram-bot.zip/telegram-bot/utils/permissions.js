/**
 * Vérifie si un utilisateur est admin/créateur du groupe Telegram actuel.
 * En message privé, il n'y a pas de notion d'admin : on renvoie true
 * pour ne pas bloquer inutilement les commandes en DM.
 */
async function isChatAdmin(ctx, userId = ctx.from.id) {
  if (ctx.chat.type === "private") return true;
  try {
    const member = await ctx.telegram.getChatMember(ctx.chat.id, userId);
    return member.status === "administrator" || member.status === "creator";
  } catch {
    return false;
  }
}

/**
 * Résout l'utilisateur ciblé par une commande de modération :
 * en réponse à son message, ou via un ID numérique en argument.
 * (Telegram ne permet pas de résoudre un @username en ID sans que
 * l'utilisateur ait déjà interagi avec le bot, d'où la limitation.)
 */
function getTargetUser(ctx) {
  if (ctx.message.reply_to_message) {
    return ctx.message.reply_to_message.from;
  }
  const arg = ctx.message.text.trim().split(/\s+/)[1];
  if (arg && /^\d+$/.test(arg)) {
    return { id: Number(arg), first_name: arg };
  }
  return null;
}

module.exports = { isChatAdmin, getTargetUser };
