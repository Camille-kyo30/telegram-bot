const fs = require("fs");
const path = require("path");

/**
 * Charge tous les fichiers d'events du dossier /events.
 * Chaque event exporte : { config: { name, type }, run(ctx) }
 * `type` correspond à un type d'update Telegram/Telegraf :
 *  - "new_chat_members" (arrivée dans un groupe -> welcome.js)
 *  - "left_chat_member"  (départ d'un groupe -> leave.js)
 *  - "any"               (déclenché sur chaque update -> logsbot.js, checkwarn.js, onEvent.js)
 * Les fichiers *.eg.js sont des exemples/templates et ne sont pas chargés.
 */
function loadEvents(eventsDir) {
  const events = [];
  const files = fs
    .readdirSync(eventsDir)
    .filter((f) => f.endsWith(".js") && !f.endsWith(".eg.js"));

  for (const file of files) {
    const fullPath = path.join(eventsDir, file);
    delete require.cache[require.resolve(fullPath)];
    try {
      const evt = require(fullPath);
      if (!evt.config || !evt.config.name || typeof evt.run !== "function") {
        console.warn(`[eventLoader] Fichier ignoré (format invalide) : ${file}`);
        continue;
      }
      events.push(evt);
      console.log(`[eventLoader] Event chargé : ${evt.config.name} (${evt.config.type})`);
    } catch (err) {
      console.error(`[eventLoader] Erreur en chargeant ${file} :`, err);
    }
  }

  return events;
}

module.exports = { loadEvents };
