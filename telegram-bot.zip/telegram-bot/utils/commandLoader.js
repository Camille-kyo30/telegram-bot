const fs = require("fs");
const path = require("path");

/**
 * Charge tous les fichiers de commandes du dossier /commands.
 * Chaque commande exporte : { config: { name, aliases, description, usage, ownerOnly }, run(ctx, extra) }
 * Convention proche de GoatBot : un fichier = une commande, rechargeable à chaud.
 */
function loadCommands(commandsDir) {
  const commands = new Map();

  const files = fs.readdirSync(commandsDir).filter((f) => f.endsWith(".js"));

  for (const file of files) {
    const fullPath = path.join(commandsDir, file);
    delete require.cache[require.resolve(fullPath)]; // permet le hot-reload
    try {
      const cmd = require(fullPath);
      if (!cmd.config || !cmd.config.name || typeof cmd.run !== "function") {
        console.warn(`[commandLoader] Fichier ignoré (format invalide) : ${file}`);
        continue;
      }
      commands.set(cmd.config.name.toLowerCase(), cmd);
      (cmd.config.aliases || []).forEach((alias) =>
        commands.set(alias.toLowerCase(), cmd)
      );
      console.log(`[commandLoader] Commande chargée : ${cmd.config.name}`);
    } catch (err) {
      console.error(`[commandLoader] Erreur en chargeant ${file} :`, err);
    }
  }

  return commands;
}

module.exports = { loadCommands };
