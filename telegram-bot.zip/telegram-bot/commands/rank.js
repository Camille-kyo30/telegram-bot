module.exports = {
  config: {
    name: "rank",
    aliases: [],
    description: "TODO : décrire la commande rank",
    usage: "/rank",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande rank
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /rank pas encore implémentée.");
  },
};
