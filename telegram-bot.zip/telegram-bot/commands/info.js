const os = require("os");

const startTime = Date.now();

module.exports = {
  config: {
    name: "info",
    aliases: ["botinfo"],
    description: "Affiche les informations générales du bot",
    usage: "/info",
    ownerOnly: false,
  },
  async run(ctx, { commands }) {
    const uptimeMs = Date.now() - startTime;
    const uptime = formatDuration(uptimeMs);
    const uniqueCommands = new Set([...commands.values()]).size;

    ctx.reply(
      `🍓━━━━━━━━🍓\n` +
        `🤖 Nom : Mon Bot Telegram\n` +
        `⏱️ Uptime : ${uptime}\n` +
        `📦 Commandes chargées : ${uniqueCommands}\n` +
        `💻 Node.js : ${process.version}\n` +
        `🖥️ Plateforme : ${os.platform()}\n` +
        `🍓━━━━━━━━🍓`
    );
  },
};

function formatDuration(ms) {
  const s = Math.floor(ms / 1000) % 60;
  const m = Math.floor(ms / 60000) % 60;
  const h = Math.floor(ms / 3600000);
  return `${h}h ${m}m ${s}s`;
}
