module.exports = {
  config: {
    name: "sendnoti",
    aliases: [],
    description: "TODO : décrire la commande sendnoti",
    usage: "/sendnoti",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande sendnoti
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /sendnoti pas encore implémentée.");
  },
};
