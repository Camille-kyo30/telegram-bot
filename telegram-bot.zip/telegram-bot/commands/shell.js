module.exports = {
  config: {
    name: "shell",
    aliases: [],
    description: "TODO : décrire la commande shell",
    usage: "/shell",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande shell
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /shell pas encore implémentée.");
  },
};
