module.exports = {
  config: {
    name: "autoreaction",
    aliases: [],
    description: "TODO : décrire la commande autoreaction",
    usage: "/autoreaction",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande autoreaction
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /autoreaction pas encore implémentée.");
  },
};
