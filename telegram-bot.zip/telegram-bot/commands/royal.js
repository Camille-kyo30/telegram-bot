module.exports = {
  config: {
    name: "royal",
    aliases: [],
    description: "TODO : décrire la commande royal",
    usage: "/royal",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande royal
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /royal pas encore implémentée.");
  },
};
