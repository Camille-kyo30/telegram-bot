module.exports = {
  config: {
    name: "naruto",
    aliases: [],
    description: "TODO : décrire la commande naruto",
    usage: "/naruto",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande naruto
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /naruto pas encore implémentée.");
  },
};
