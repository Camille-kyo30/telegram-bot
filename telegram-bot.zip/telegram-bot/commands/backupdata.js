module.exports = {
  config: {
    name: "backupdata",
    aliases: [],
    description: "TODO : décrire la commande backupdata",
    usage: "/backupdata",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande backupdata
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /backupdata pas encore implémentée.");
  },
};
