module.exports = {
  config: {
    name: "penalty",
    aliases: [],
    description: "TODO : décrire la commande penalty",
    usage: "/penalty",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande penalty
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /penalty pas encore implémentée.");
  },
};
