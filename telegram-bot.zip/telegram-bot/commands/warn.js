const { isChatAdmin, getTargetUser } = require("../utils/permissions");
const { readDb, writeDb } = require("../utils/db");

const MAX_WARNS = 3;

module.exports = {
  config: {
    name: "warn",
    aliases: [],
    description: `Avertit un utilisateur (ban automatique au ${MAX_WARNS}e avertissement)`,
    usage: "/warn (en réponse à un message)",
    ownerOnly: false,
  },
  async run(ctx) {
    if (ctx.chat.type === "private") {
      return ctx.reply("⚠️ Commande utilisable seulement dans un groupe.");
    }
    if (!(await isChatAdmin(ctx))) {
      return ctx.reply("⛔ Réservé aux admins du groupe.");
    }

    const target = getTargetUser(ctx);
    if (!target) {
      return ctx.reply("⚠️ Réponds au message de la personne à avertir.");
    }

    const db = readDb();
    const chatId = String(ctx.chat.id);
    const userId = String(target.id);
    db.warns[chatId] = db.warns[chatId] || {};
    db.warns[chatId][userId] = (db.warns[chatId][userId] || 0) + 1;
    const count = db.warns[chatId][userId];

    if (count >= MAX_WARNS) {
      db.warns[chatId][userId] = 0;
      writeDb(db);
      try {
        await ctx.telegram.banChatMember(ctx.chat.id, target.id);
        return ctx.reply(
          `🔨 ${target.first_name || target.id} a atteint ${MAX_WARNS} avertissements et a été banni.`
        );
      } catch {
        return ctx.reply(
          `⚠️ ${count}/${MAX_WARNS} avertissements, mais le bannissement a échoué (le bot est-il admin ?).`
        );
      }
    }

    writeDb(db);
    ctx.reply(`⚠️ ${target.first_name || target.id} averti (${count}/${MAX_WARNS}).`);
  },
};
