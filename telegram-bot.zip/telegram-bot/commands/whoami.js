module.exports = {
  config: {
    name: "whoami",
    aliases: ["moi", "id"],
    description: "Affiche tes informations Telegram (ID, nom, chat)",
    usage: "/whoami",
    ownerOnly: false,
  },
  async run(ctx) {
    const { id, first_name, username } = ctx.from;
    ctx.reply(
      `🍓━━━━━━━━🍓\n` +
        `👤 Nom : ${first_name}\n` +
        `🔖 Username : ${username ? "@" + username : "aucun"}\n` +
        `🆔 ID : ${id}\n` +
        `💬 Chat ID : ${ctx.chat.id}\n` +
        `🍓━━━━━━━━🍓`
    );
  },
};
