module.exports = {
  config: {
    name: "dhbc",
    aliases: [],
    description: "TODO : décrire la commande dhbc",
    usage: "/dhbc",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande dhbc
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /dhbc pas encore implémentée.");
  },
};
