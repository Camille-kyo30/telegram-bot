const { isChatAdmin, getTargetUser } = require("../utils/permissions");

module.exports = {
  config: {
    name: "ban",
    aliases: [],
    description: "Bannit un utilisateur du groupe (reply ou ID)",
    usage: "/ban (en réponse à un message, ou /ban <id>)",
    ownerOnly: false,
  },
  async run(ctx) {
    if (ctx.chat.type === "private") {
      return ctx.reply("⚠️ Commande utilisable seulement dans un groupe.");
    }
    if (!(await isChatAdmin(ctx))) {
      return ctx.reply("⛔ Réservé aux admins du groupe.");
    }

    const target = getTargetUser(ctx);
    if (!target) {
      return ctx.reply("⚠️ Réponds au message de la personne à bannir, ou fais /ban <id>.");
    }

    try {
      await ctx.telegram.banChatMember(ctx.chat.id, target.id);
      ctx.reply(`🔨 ${target.first_name || target.id} a été banni du groupe.`);
    } catch (err) {
      ctx.reply("❌ Impossible de bannir cet utilisateur (le bot est-il admin ?).");
    }
  },
};
