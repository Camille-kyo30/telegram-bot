module.exports = {
  config: {
    name: "jsontosqlite",
    aliases: [],
    description: "TODO : décrire la commande jsontosqlite",
    usage: "/jsontosqlite",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande jsontosqlite
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /jsontosqlite pas encore implémentée.");
  },
};
