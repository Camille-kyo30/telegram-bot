module.exports = {
  config: {
    name: "emojimix",
    aliases: [],
    description: "TODO : décrire la commande emojimix",
    usage: "/emojimix",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande emojimix
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /emojimix pas encore implémentée.");
  },
};
