module.exports = {
  config: {
    name: "candycrush",
    aliases: [],
    description: "TODO : décrire la commande candycrush",
    usage: "/candycrush",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande candycrush
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /candycrush pas encore implémentée.");
  },
};
