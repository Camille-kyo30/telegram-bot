module.exports = {
  config: {
    name: "acp",
    aliases: [],
    description: "TODO : décrire la commande acp",
    usage: "/acp",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande acp
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /acp pas encore implémentée.");
  },
};
