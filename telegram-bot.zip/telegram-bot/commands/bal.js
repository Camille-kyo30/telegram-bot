module.exports = {
  config: {
    name: "bal",
    aliases: [],
    description: "TODO : décrire la commande bal",
    usage: "/bal",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande bal
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /bal pas encore implémentée.");
  },
};
