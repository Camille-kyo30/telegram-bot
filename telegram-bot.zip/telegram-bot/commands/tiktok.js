module.exports = {
  config: {
    name: "tiktok",
    aliases: [],
    description: "TODO : décrire la commande tiktok",
    usage: "/tiktok",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande tiktok
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /tiktok pas encore implémentée.");
  },
};
