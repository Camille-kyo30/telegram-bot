module.exports = {
  config: {
    name: "dev",
    aliases: [],
    description: "TODO : décrire la commande dev",
    usage: "/dev",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande dev
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /dev pas encore implémentée.");
  },
};
