module.exports = {
  config: {
    name: "admin",
    aliases: [],
    description: "TODO : décrire la commande admin",
    usage: "/admin",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande admin
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /admin pas encore implémentée.");
  },
};
