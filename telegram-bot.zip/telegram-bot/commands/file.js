module.exports = {
  config: {
    name: "file",
    aliases: [],
    description: "TODO : décrire la commande file",
    usage: "/file",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande file
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /file pas encore implémentée.");
  },
};
