module.exports = {
  config: {
    name: "bowling",
    aliases: [],
    description: "TODO : décrire la commande bowling",
    usage: "/bowling",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande bowling
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /bowling pas encore implémentée.");
  },
};
