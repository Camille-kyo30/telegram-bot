module.exports = {
  config: {
    name: "galaxy",
    aliases: [],
    description: "TODO : décrire la commande galaxy",
    usage: "/galaxy",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande galaxy
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /galaxy pas encore implémentée.");
  },
};
