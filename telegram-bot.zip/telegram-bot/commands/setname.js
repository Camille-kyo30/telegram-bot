module.exports = {
  config: {
    name: "setname",
    aliases: [],
    description: "TODO : décrire la commande setname",
    usage: "/setname",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande setname
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /setname pas encore implémentée.");
  },
};
