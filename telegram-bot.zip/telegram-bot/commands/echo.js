module.exports = {
  config: {
    name: "echo",
    aliases: ["say"],
    description: "Répète le texte fourni",
    usage: "/echo <texte>",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    if (!args.length) return ctx.reply("⚠️ Usage : /echo <texte>");
    ctx.reply(args.join(" "));
  },
};
