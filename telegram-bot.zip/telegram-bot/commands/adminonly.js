const { isChatAdmin } = require("../utils/permissions");
const { readDb, writeDb } = require("../utils/db");

module.exports = {
  config: {
    name: "adminonly",
    aliases: [],
    description: "Restreint l'usage des commandes du bot aux admins du groupe",
    usage: "/adminonly <on|off>",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    if (ctx.chat.type === "private") {
      return ctx.reply("⚠️ Commande utilisable seulement dans un groupe.");
    }
    if (!(await isChatAdmin(ctx))) {
      return ctx.reply("⛔ Réservé aux admins du groupe.");
    }

    const mode = (args[0] || "").toLowerCase();
    if (!["on", "off"].includes(mode)) {
      return ctx.reply("⚠️ Usage : /adminonly <on|off>");
    }

    const db = readDb();
    const chatId = String(ctx.chat.id);
    db.adminOnly[chatId] = mode === "on";
    writeDb(db);

    ctx.reply(
      mode === "on"
        ? "🔒 Seuls les admins peuvent désormais utiliser le bot ici."
        : "🔓 Tout le monde peut à nouveau utiliser le bot ici."
    );
  },
};
