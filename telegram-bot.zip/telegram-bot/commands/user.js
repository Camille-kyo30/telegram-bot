module.exports = {
  config: {
    name: "user",
    aliases: [],
    description: "TODO : décrire la commande user",
    usage: "/user",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande user
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /user pas encore implémentée.");
  },
};
