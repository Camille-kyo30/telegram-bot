module.exports = {
  config: {
    name: "video",
    aliases: [],
    description: "TODO : décrire la commande video",
    usage: "/video",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande video
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /video pas encore implémentée.");
  },
};
