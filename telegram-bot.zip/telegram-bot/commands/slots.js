module.exports = {
  config: {
    name: "slots",
    aliases: [],
    description: "TODO : décrire la commande slots",
    usage: "/slots",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande slots
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /slots pas encore implémentée.");
  },
};
