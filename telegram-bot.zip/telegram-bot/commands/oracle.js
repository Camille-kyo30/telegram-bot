module.exports = {
  config: {
    name: "oracle",
    aliases: [],
    description: "TODO : décrire la commande oracle",
    usage: "/oracle",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande oracle
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /oracle pas encore implémentée.");
  },
};
