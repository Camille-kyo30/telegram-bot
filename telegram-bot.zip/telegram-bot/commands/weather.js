module.exports = {
  config: {
    name: "weather",
    aliases: [],
    description: "TODO : décrire la commande weather",
    usage: "/weather",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande weather
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /weather pas encore implémentée.");
  },
};
