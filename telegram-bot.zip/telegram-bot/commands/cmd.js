module.exports = {
  config: {
    name: "cmd",
    aliases: [],
    description: "TODO : décrire la commande cmd",
    usage: "/cmd",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande cmd
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /cmd pas encore implémentée.");
  },
};
