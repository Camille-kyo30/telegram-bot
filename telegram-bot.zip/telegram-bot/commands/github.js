module.exports = {
  config: {
    name: "github",
    aliases: [],
    description: "TODO : décrire la commande github",
    usage: "/github",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande github
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /github pas encore implémentée.");
  },
};
