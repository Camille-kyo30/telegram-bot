module.exports = {
  config: {
    name: "guessnumber",
    aliases: [],
    description: "TODO : décrire la commande guessnumber",
    usage: "/guessnumber",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande guessnumber
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /guessnumber pas encore implémentée.");
  },
};
