module.exports = {
  config: {
    name: "flux",
    aliases: [],
    description: "TODO : décrire la commande flux",
    usage: "/flux",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande flux
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /flux pas encore implémentée.");
  },
};
