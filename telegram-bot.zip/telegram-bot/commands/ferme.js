module.exports = {
  config: {
    name: "ferme",
    aliases: [],
    description: "TODO : décrire la commande ferme",
    usage: "/ferme",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande ferme
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /ferme pas encore implémentée.");
  },
};
