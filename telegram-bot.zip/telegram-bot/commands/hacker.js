module.exports = {
  config: {
    name: "hacker",
    aliases: [],
    description: "TODO : décrire la commande hacker",
    usage: "/hacker",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande hacker
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /hacker pas encore implémentée.");
  },
};
