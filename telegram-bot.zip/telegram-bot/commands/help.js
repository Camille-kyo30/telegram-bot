module.exports = {
  config: {
    name: "help",
    aliases: ["aide", "commands"],
    description: "Affiche la liste des commandes disponibles",
    usage: "/help [commande]",
    ownerOnly: false,
  },
  async run(ctx, { args, commands }) {
    if (args[0]) {
      const cmd = commands.get(args[0].toLowerCase());
      if (!cmd) return ctx.reply("❌ Commande introuvable.");
      return ctx.reply(
        `🍓━━━━━━━━🍓\n` +
          `📌 ${cmd.config.name}\n` +
          `📝 ${cmd.config.description}\n` +
          `⚙️ Usage : ${cmd.config.usage}\n` +
          `🍓━━━━━━━━🍓`
      );
    }

    const uniqueNames = [...new Set([...commands.values()])];
    const list = uniqueNames
      .map((c) => `• ${c.config.name} — ${c.config.description}`)
      .join("\n");

    ctx.reply(`🍓━━━━━━━━🍓\n📋 Commandes disponibles :\n\n${list}\n🍓━━━━━━━━🍓`);
  },
};
