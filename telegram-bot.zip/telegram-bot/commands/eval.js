module.exports = {
  config: {
    name: "eval",
    aliases: [],
    description: "TODO : décrire la commande eval",
    usage: "/eval",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande eval
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /eval pas encore implémentée.");
  },
};
