module.exports = {
  config: {
    name: "adduser",
    aliases: [],
    description: "TODO : décrire la commande adduser",
    usage: "/adduser",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande adduser
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /adduser pas encore implémentée.");
  },
};
