module.exports = {
  config: {
    name: "quiz",
    aliases: [],
    description: "TODO : décrire la commande quiz",
    usage: "/quiz",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande quiz
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /quiz pas encore implémentée.");
  },
};
