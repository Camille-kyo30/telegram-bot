module.exports = {
  config: {
    name: "poker",
    aliases: [],
    description: "TODO : décrire la commande poker",
    usage: "/poker",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande poker
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /poker pas encore implémentée.");
  },
};
