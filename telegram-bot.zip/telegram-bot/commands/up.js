module.exports = {
  config: {
    name: "up",
    aliases: [],
    description: "TODO : décrire la commande up",
    usage: "/up",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande up
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /up pas encore implémentée.");
  },
};
