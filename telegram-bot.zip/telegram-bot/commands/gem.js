module.exports = {
  config: {
    name: "gem",
    aliases: [],
    description: "TODO : décrire la commande gem",
    usage: "/gem",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande gem
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /gem pas encore implémentée.");
  },
};
