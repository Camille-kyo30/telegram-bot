module.exports = {
  config: {
    name: "calc",
    aliases: ["calcul", "math"],
    description: "Évalue une expression mathématique simple",
    usage: "/calc <expression>  (ex: /calc 12*(3+4))",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    const expr = args.join(" ");
    if (!expr) return ctx.reply("⚠️ Usage : /calc <expression>");

    // N'autorise que chiffres, espaces et opérateurs de base : évite tout eval() dangereux
    if (!/^[0-9+\-*/().\s]+$/.test(expr)) {
      return ctx.reply("⚠️ Expression invalide : seuls les nombres et + - * / ( ) sont autorisés.");
    }

    try {
      // Function() isolé, sans accès au scope englobant, restreint par la regex ci-dessus
      const result = Function(`"use strict"; return (${expr})`)();
      ctx.reply(`🧮 ${expr} = ${result}`);
    } catch {
      ctx.reply("❌ Impossible d'évaluer cette expression.");
    }
  },
};
