module.exports = {
  config: {
    name: "top",
    aliases: [],
    description: "TODO : décrire la commande top",
    usage: "/top",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande top
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /top pas encore implémentée.");
  },
};
