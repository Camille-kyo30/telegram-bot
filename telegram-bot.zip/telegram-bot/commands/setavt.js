module.exports = {
  config: {
    name: "setavt",
    aliases: [],
    description: "TODO : décrire la commande setavt",
    usage: "/setavt",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande setavt
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /setavt pas encore implémentée.");
  },
};
