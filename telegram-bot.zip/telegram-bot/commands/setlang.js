module.exports = {
  config: {
    name: "setlang",
    aliases: [],
    description: "TODO : décrire la commande setlang",
    usage: "/setlang",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande setlang
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /setlang pas encore implémentée.");
  },
};
