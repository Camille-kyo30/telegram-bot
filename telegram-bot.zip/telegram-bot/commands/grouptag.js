module.exports = {
  config: {
    name: "grouptag",
    aliases: [],
    description: "TODO : décrire la commande grouptag",
    usage: "/grouptag",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande grouptag
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /grouptag pas encore implémentée.");
  },
};
