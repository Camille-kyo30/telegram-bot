module.exports = {
  config: {
    name: "jsontomongodb",
    aliases: [],
    description: "TODO : décrire la commande jsontomongodb",
    usage: "/jsontomongodb",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande jsontomongodb
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /jsontomongodb pas encore implémentée.");
  },
};
