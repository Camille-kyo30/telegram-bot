module.exports = {
  config: {
    name: "gpt",
    aliases: [],
    description: "TODO : décrire la commande gpt",
    usage: "/gpt",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande gpt
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /gpt pas encore implémentée.");
  },
};
