module.exports = {
  config: {
    name: "blackjack",
    aliases: [],
    description: "TODO : décrire la commande blackjack",
    usage: "/blackjack",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande blackjack
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /blackjack pas encore implémentée.");
  },
};
