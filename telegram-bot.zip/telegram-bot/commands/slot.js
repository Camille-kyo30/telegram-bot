module.exports = {
  config: {
    name: "slot",
    aliases: [],
    description: "TODO : décrire la commande slot",
    usage: "/slot",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande slot
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /slot pas encore implémentée.");
  },
};
