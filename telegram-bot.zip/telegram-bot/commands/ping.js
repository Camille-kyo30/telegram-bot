module.exports = {
  config: {
    name: "ping",
    aliases: [],
    description: "Vérifie que le bot répond et affiche la latence",
    usage: "/ping",
    ownerOnly: false,
  },
  async run(ctx) {
    const start = Date.now();
    const sent = await ctx.reply("🏓 Pong...");
    const latency = Date.now() - start;
    ctx.telegram.editMessageText(
      sent.chat.id,
      sent.message_id,
      undefined,
      `🏓 Pong ! (${latency} ms)`
    );
  },
};
