module.exports = {
  config: {
    name: "edit",
    aliases: [],
    description: "TODO : décrire la commande edit",
    usage: "/edit",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande edit
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /edit pas encore implémentée.");
  },
};
