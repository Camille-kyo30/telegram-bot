module.exports = {
  config: {
    name: "loadconfig",
    aliases: [],
    description: "TODO : décrire la commande loadconfig",
    usage: "/loadconfig",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande loadconfig
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /loadconfig pas encore implémentée.");
  },
};
