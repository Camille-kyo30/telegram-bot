module.exports = {
  config: {
    name: "setwelcome",
    aliases: [],
    description: "TODO : décrire la commande setwelcome",
    usage: "/setwelcome",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande setwelcome
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /setwelcome pas encore implémentée.");
  },
};
