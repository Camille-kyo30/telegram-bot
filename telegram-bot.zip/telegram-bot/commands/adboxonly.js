module.exports = {
  config: {
    name: "adboxonly",
    aliases: [],
    description: "TODO : décrire la commande adboxonly",
    usage: "/adboxonly",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande adboxonly
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /adboxonly pas encore implémentée.");
  },
};
