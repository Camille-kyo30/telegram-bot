module.exports = {
  config: {
    name: "sorthelp",
    aliases: [],
    description: "TODO : décrire la commande sorthelp",
    usage: "/sorthelp",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande sorthelp
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /sorthelp pas encore implémentée.");
  },
};
