module.exports = {
  config: {
    name: "imgbb",
    aliases: [],
    description: "TODO : décrire la commande imgbb",
    usage: "/imgbb",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande imgbb
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /imgbb pas encore implémentée.");
  },
};
