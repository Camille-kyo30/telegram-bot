module.exports = {
  config: {
    name: "pair",
    aliases: [],
    description: "TODO : décrire la commande pair",
    usage: "/pair",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande pair
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /pair pas encore implémentée.");
  },
};
