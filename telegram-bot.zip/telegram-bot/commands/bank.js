module.exports = {
  config: {
    name: "bank",
    aliases: [],
    description: "TODO : décrire la commande bank",
    usage: "/bank",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande bank
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /bank pas encore implémentée.");
  },
};
