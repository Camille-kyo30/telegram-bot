module.exports = {
  config: {
    name: "supportgc",
    aliases: [],
    description: "TODO : décrire la commande supportgc",
    usage: "/supportgc",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande supportgc
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /supportgc pas encore implémentée.");
  },
};
