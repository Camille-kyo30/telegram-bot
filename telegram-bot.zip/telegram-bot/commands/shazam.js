module.exports = {
  config: {
    name: "shazam",
    aliases: [],
    description: "TODO : décrire la commande shazam",
    usage: "/shazam",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande shazam
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /shazam pas encore implémentée.");
  },
};
