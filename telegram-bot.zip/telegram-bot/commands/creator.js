module.exports = {
  config: {
    name: "creator",
    aliases: [],
    description: "TODO : décrire la commande creator",
    usage: "/creator",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande creator
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /creator pas encore implémentée.");
  },
};
