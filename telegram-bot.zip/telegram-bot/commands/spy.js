module.exports = {
  config: {
    name: "spy",
    aliases: [],
    description: "TODO : décrire la commande spy",
    usage: "/spy",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande spy
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /spy pas encore implémentée.");
  },
};
