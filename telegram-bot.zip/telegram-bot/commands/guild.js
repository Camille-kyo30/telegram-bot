module.exports = {
  config: {
    name: "guild",
    aliases: [],
    description: "TODO : décrire la commande guild",
    usage: "/guild",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande guild
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /guild pas encore implémentée.");
  },
};
