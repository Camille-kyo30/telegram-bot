module.exports = {
  config: {
    name: "rankup",
    aliases: [],
    description: "TODO : décrire la commande rankup",
    usage: "/rankup",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande rankup
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /rankup pas encore implémentée.");
  },
};
