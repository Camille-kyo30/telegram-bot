module.exports = {
  config: {
    name: "pending",
    aliases: [],
    description: "TODO : décrire la commande pending",
    usage: "/pending",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande pending
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /pending pas encore implémentée.");
  },
};
