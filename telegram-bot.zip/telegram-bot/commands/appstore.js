module.exports = {
  config: {
    name: "appstore",
    aliases: [],
    description: "TODO : décrire la commande appstore",
    usage: "/appstore",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande appstore
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /appstore pas encore implémentée.");
  },
};
