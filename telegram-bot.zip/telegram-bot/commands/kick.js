const { isChatAdmin, getTargetUser } = require("../utils/permissions");

module.exports = {
  config: {
    name: "kick",
    aliases: [],
    description: "Expulse un utilisateur du groupe (il peut revenir, contrairement à /ban)",
    usage: "/kick (en réponse à un message, ou /kick <id>)",
    ownerOnly: false,
  },
  async run(ctx) {
    if (ctx.chat.type === "private") {
      return ctx.reply("⚠️ Commande utilisable seulement dans un groupe.");
    }
    if (!(await isChatAdmin(ctx))) {
      return ctx.reply("⛔ Réservé aux admins du groupe.");
    }

    const target = getTargetUser(ctx);
    if (!target) {
      return ctx.reply("⚠️ Réponds au message de la personne à expulser, ou fais /kick <id>.");
    }

    try {
      await ctx.telegram.banChatMember(ctx.chat.id, target.id);
      await ctx.telegram.unbanChatMember(ctx.chat.id, target.id);
      ctx.reply(`👢 ${target.first_name || target.id} a été expulsé du groupe.`);
    } catch (err) {
      ctx.reply("❌ Impossible d'expulser cet utilisateur (le bot est-il admin ?).");
    }
  },
};
