module.exports = {
  config: {
    name: "imgur",
    aliases: [],
    description: "TODO : décrire la commande imgur",
    usage: "/imgur",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande imgur
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /imgur pas encore implémentée.");
  },
};
