module.exports = {
  config: {
    name: "setleave",
    aliases: [],
    description: "TODO : décrire la commande setleave",
    usage: "/setleave",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande setleave
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /setleave pas encore implémentée.");
  },
};
