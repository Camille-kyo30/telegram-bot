module.exports = {
  config: {
    name: "join",
    aliases: [],
    description: "TODO : décrire la commande join",
    usage: "/join",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande join
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /join pas encore implémentée.");
  },
};
