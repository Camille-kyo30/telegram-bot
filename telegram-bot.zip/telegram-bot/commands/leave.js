module.exports = {
  config: {
    name: "leave",
    aliases: [],
    description: "TODO : décrire la commande leave",
    usage: "/leave",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande leave
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /leave pas encore implémentée.");
  },
};
