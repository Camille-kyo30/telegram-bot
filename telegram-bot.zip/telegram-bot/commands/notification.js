module.exports = {
  config: {
    name: "notification",
    aliases: [],
    description: "TODO : décrire la commande notification",
    usage: "/notification",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande notification
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /notification pas encore implémentée.");
  },
};
