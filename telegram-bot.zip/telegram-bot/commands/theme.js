module.exports = {
  config: {
    name: "theme",
    aliases: [],
    description: "TODO : décrire la commande theme",
    usage: "/theme",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande theme
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /theme pas encore implémentée.");
  },
};
