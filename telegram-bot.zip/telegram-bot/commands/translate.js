module.exports = {
  config: {
    name: "translate",
    aliases: [],
    description: "TODO : décrire la commande translate",
    usage: "/translate",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande translate
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /translate pas encore implémentée.");
  },
};
