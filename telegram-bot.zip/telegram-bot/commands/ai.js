module.exports = {
  config: {
    name: "ai",
    aliases: [],
    description: "TODO : décrire la commande ai",
    usage: "/ai",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande ai
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /ai pas encore implémentée.");
  },
};
