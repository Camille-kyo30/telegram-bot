module.exports = {
  config: {
    name: "font",
    aliases: [],
    description: "TODO : décrire la commande font",
    usage: "/font",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande font
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /font pas encore implémentée.");
  },
};
