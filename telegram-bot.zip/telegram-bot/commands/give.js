module.exports = {
  config: {
    name: "give",
    aliases: [],
    description: "TODO : décrire la commande give",
    usage: "/give",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande give
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /give pas encore implémentée.");
  },
};
