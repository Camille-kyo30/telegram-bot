module.exports = {
  config: {
    name: "restart",
    aliases: [],
    description: "TODO : décrire la commande restart",
    usage: "/restart",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande restart
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /restart pas encore implémentée.");
  },
};
