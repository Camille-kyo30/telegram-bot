module.exports = {
  config: {
    name: "mj",
    aliases: [],
    description: "TODO : décrire la commande mj",
    usage: "/mj",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande mj
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /mj pas encore implémentée.");
  },
};
