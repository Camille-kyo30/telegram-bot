module.exports = {
  config: {
    name: "ludo",
    aliases: [],
    description: "TODO : décrire la commande ludo",
    usage: "/ludo",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande ludo
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /ludo pas encore implémentée.");
  },
};
