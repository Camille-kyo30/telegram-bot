module.exports = {
  config: {
    name: "Mini",
    aliases: [],
    description: "TODO : décrire la commande Mini",
    usage: "/Mini",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande Mini
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /Mini pas encore implémentée.");
  },
};
