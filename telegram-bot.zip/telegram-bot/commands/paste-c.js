module.exports = {
  config: {
    name: "paste-c",
    aliases: [],
    description: "TODO : décrire la commande paste-c",
    usage: "/paste-c",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande paste-c
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /paste-c pas encore implémentée.");
  },
};
