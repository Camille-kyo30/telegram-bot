module.exports = {
  config: {
    name: "pirates",
    aliases: [],
    description: "TODO : décrire la commande pirates",
    usage: "/pirates",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande pirates
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /pirates pas encore implémentée.");
  },
};
