module.exports = {
  config: {
    name: "profile",
    aliases: [],
    description: "TODO : décrire la commande profile",
    usage: "/profile",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande profile
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /profile pas encore implémentée.");
  },
};
