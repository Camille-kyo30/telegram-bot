module.exports = {
  config: {
    name: "dice",
    aliases: ["de", "roll"],
    description: "Lance un dé (6 faces par défaut, ou /dice <faces>)",
    usage: "/dice [faces]",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    const faces = parseInt(args[0], 10) || 6;
    if (faces < 2 || faces > 1000) {
      return ctx.reply("⚠️ Choisis un nombre de faces entre 2 et 1000.");
    }
    const result = Math.floor(Math.random() * faces) + 1;
    ctx.reply(`🎲 Résultat : ${result} / ${faces}`);
  },
};
