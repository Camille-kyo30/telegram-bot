module.exports = {
  config: {
    name: "sunoai",
    aliases: [],
    description: "TODO : décrire la commande sunoai",
    usage: "/sunoai",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande sunoai
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /sunoai pas encore implémentée.");
  },
};
