module.exports = {
  config: {
    name: "Count",
    aliases: [],
    description: "TODO : décrire la commande Count",
    usage: "/Count",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande Count
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /Count pas encore implémentée.");
  },
};
