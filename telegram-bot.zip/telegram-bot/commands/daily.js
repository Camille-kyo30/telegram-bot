module.exports = {
  config: {
    name: "daily",
    aliases: [],
    description: "TODO : décrire la commande daily",
    usage: "/daily",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande daily
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /daily pas encore implémentée.");
  },
};
