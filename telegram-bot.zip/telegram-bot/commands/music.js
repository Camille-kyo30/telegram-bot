module.exports = {
  config: {
    name: "music",
    aliases: [],
    description: "TODO : décrire la commande music",
    usage: "/music",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande music
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /music pas encore implémentée.");
  },
};
