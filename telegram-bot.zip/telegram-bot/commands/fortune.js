module.exports = {
  config: {
    name: "fortune",
    aliases: [],
    description: "TODO : décrire la commande fortune",
    usage: "/fortune",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande fortune
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /fortune pas encore implémentée.");
  },
};
