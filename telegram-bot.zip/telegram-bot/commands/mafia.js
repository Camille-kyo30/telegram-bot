module.exports = {
  config: {
    name: "mafia",
    aliases: [],
    description: "TODO : décrire la commande mafia",
    usage: "/mafia",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande mafia
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /mafia pas encore implémentée.");
  },
};
