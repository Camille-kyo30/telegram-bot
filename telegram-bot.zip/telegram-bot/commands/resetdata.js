module.exports = {
  config: {
    name: "resetdata",
    aliases: [],
    description: "TODO : décrire la commande resetdata",
    usage: "/resetdata",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande resetdata
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /resetdata pas encore implémentée.");
  },
};
