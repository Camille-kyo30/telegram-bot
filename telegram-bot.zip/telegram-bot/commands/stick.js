module.exports = {
  config: {
    name: "stick",
    aliases: [],
    description: "TODO : décrire la commande stick",
    usage: "/stick",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande stick
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /stick pas encore implémentée.");
  },
};
