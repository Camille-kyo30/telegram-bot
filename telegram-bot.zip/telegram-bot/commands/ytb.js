module.exports = {
  config: {
    name: "ytb",
    aliases: [],
    description: "TODO : décrire la commande ytb",
    usage: "/ytb",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande ytb
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /ytb pas encore implémentée.");
  },
};
