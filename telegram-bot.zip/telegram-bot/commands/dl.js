module.exports = {
  config: {
    name: "dl",
    aliases: [],
    description: "TODO : décrire la commande dl",
    usage: "/dl",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande dl
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /dl pas encore implémentée.");
  },
};
