module.exports = {
  config: {
    name: "prefix",
    aliases: [],
    description: "TODO : décrire la commande prefix",
    usage: "/prefix",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande prefix
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /prefix pas encore implémentée.");
  },
};
