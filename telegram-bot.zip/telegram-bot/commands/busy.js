module.exports = {
  config: {
    name: "busy",
    aliases: [],
    description: "TODO : décrire la commande busy",
    usage: "/busy",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande busy
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /busy pas encore implémentée.");
  },
};
