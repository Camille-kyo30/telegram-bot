module.exports = {
  config: {
    name: "leaveall",
    aliases: [],
    description: "TODO : décrire la commande leaveall",
    usage: "/leaveall",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande leaveall
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /leaveall pas encore implémentée.");
  },
};
