module.exports = {
  config: {
    name: "ignoreonlyadbox",
    aliases: [],
    description: "TODO : décrire la commande ignoreonlyadbox",
    usage: "/ignoreonlyadbox",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande ignoreonlyadbox
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /ignoreonlyadbox pas encore implémentée.");
  },
};
