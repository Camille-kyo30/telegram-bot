module.exports = {
  config: {
    name: "alchimie",
    aliases: [],
    description: "TODO : décrire la commande alchimie",
    usage: "/alchimie",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande alchimie
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /alchimie pas encore implémentée.");
  },
};
