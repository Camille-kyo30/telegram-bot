module.exports = {
  config: {
    name: "sing",
    aliases: [],
    description: "TODO : décrire la commande sing",
    usage: "/sing",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande sing
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /sing pas encore implémentée.");
  },
};
