module.exports = {
  config: {
    name: "levelup",
    aliases: [],
    description: "TODO : décrire la commande levelup",
    usage: "/levelup",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande levelup
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /levelup pas encore implémentée.");
  },
};
