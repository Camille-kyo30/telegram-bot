module.exports = {
  config: {
    name: "setalias",
    aliases: [],
    description: "TODO : décrire la commande setalias",
    usage: "/setalias",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande setalias
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /setalias pas encore implémentée.");
  },
};
