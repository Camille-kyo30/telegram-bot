module.exports = {
  config: {
    name: "memory",
    aliases: [],
    description: "TODO : décrire la commande memory",
    usage: "/memory",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande memory
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /memory pas encore implémentée.");
  },
};
