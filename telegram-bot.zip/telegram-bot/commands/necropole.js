module.exports = {
  config: {
    name: "necropole",
    aliases: [],
    description: "TODO : décrire la commande necropole",
    usage: "/necropole",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande necropole
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /necropole pas encore implémentée.");
  },
};
