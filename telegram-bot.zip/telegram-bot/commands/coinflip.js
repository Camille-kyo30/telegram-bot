module.exports = {
  config: {
    name: "coinflip",
    aliases: ["pf", "pileouface"],
    description: "Lance une pièce : pile ou face",
    usage: "/coinflip",
    ownerOnly: false,
  },
  async run(ctx) {
    const result = Math.random() < 0.5 ? "Pile 🪙" : "Face 🪙";
    ctx.reply(result);
  },
};
