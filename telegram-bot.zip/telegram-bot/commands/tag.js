module.exports = {
  config: {
    name: "tag",
    aliases: [],
    description: "TODO : décrire la commande tag",
    usage: "/tag",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande tag
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /tag pas encore implémentée.");
  },
};
