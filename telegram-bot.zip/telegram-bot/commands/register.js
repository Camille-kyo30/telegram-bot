module.exports = {
  config: {
    name: "register",
    aliases: [],
    description: "TODO : décrire la commande register",
    usage: "/register",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande register
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /register pas encore implémentée.");
  },
};
