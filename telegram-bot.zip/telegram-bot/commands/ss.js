module.exports = {
  config: {
    name: "ss",
    aliases: [],
    description: "TODO : décrire la commande ss",
    usage: "/ss",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande ss
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /ss pas encore implémentée.");
  },
};
