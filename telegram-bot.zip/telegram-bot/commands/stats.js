module.exports = {
  config: {
    name: "stats",
    aliases: [],
    description: "TODO : décrire la commande stats",
    usage: "/stats",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande stats
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /stats pas encore implémentée.");
  },
};
