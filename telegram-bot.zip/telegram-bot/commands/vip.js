module.exports = {
  config: {
    name: "vip",
    aliases: [],
    description: "TODO : décrire la commande vip",
    usage: "/vip",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande vip
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /vip pas encore implémentée.");
  },
};
