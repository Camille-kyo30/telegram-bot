module.exports = {
  config: {
    name: "echecs",
    aliases: [],
    description: "TODO : décrire la commande echecs",
    usage: "/echecs",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande echecs
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /echecs pas encore implémentée.");
  },
};
