module.exports = {
  config: {
    name: "snakes",
    aliases: [],
    description: "TODO : décrire la commande snakes",
    usage: "/snakes",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande snakes
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /snakes pas encore implémentée.");
  },
};
