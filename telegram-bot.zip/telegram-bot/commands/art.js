module.exports = {
  config: {
    name: "art",
    aliases: [],
    description: "TODO : décrire la commande art",
    usage: "/art",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande art
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /art pas encore implémentée.");
  },
};
