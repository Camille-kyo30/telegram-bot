module.exports = {
  config: {
    name: "callad",
    aliases: [],
    description: "TODO : décrire la commande callad",
    usage: "/callad",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande callad
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /callad pas encore implémentée.");
  },
};
