module.exports = {
  config: {
    name: "space",
    aliases: [],
    description: "TODO : décrire la commande space",
    usage: "/space",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande space
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /space pas encore implémentée.");
  },
};
