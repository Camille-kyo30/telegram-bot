module.exports = {
  config: {
    name: "antichangeinfobox",
    aliases: [],
    description: "TODO : décrire la commande antichangeinfobox",
    usage: "/antichangeinfobox",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande antichangeinfobox
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /antichangeinfobox pas encore implémentée.");
  },
};
