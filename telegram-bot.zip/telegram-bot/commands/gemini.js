module.exports = {
  config: {
    name: "gemini",
    aliases: [],
    description: "TODO : décrire la commande gemini",
    usage: "/gemini",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande gemini
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /gemini pas encore implémentée.");
  },
};
