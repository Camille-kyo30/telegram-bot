module.exports = {
  config: {
    name: "mines",
    aliases: [],
    description: "TODO : décrire la commande mines",
    usage: "/mines",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande mines
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /mines pas encore implémentée.");
  },
};
