module.exports = {
  config: {
    name: "roulette",
    aliases: [],
    description: "TODO : décrire la commande roulette",
    usage: "/roulette",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande roulette
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /roulette pas encore implémentée.");
  },
};
