module.exports = {
  config: {
    name: "tycoon",
    aliases: [],
    description: "TODO : décrire la commande tycoon",
    usage: "/tycoon",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande tycoon
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /tycoon pas encore implémentée.");
  },
};
