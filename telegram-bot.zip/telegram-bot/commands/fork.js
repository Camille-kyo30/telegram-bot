module.exports = {
  config: {
    name: "fork",
    aliases: [],
    description: "TODO : décrire la commande fork",
    usage: "/fork",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande fork
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /fork pas encore implémentée.");
  },
};
