module.exports = {
  config: {
    name: "lyrics",
    aliases: [],
    description: "TODO : décrire la commande lyrics",
    usage: "/lyrics",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande lyrics
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /lyrics pas encore implémentée.");
  },
};
