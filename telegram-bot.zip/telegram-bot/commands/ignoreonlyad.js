module.exports = {
  config: {
    name: "ignoreonlyad",
    aliases: [],
    description: "TODO : décrire la commande ignoreonlyad",
    usage: "/ignoreonlyad",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande ignoreonlyad
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /ignoreonlyad pas encore implémentée.");
  },
};
