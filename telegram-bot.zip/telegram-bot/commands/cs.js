module.exports = {
  config: {
    name: "cs",
    aliases: [],
    description: "TODO : décrire la commande cs",
    usage: "/cs",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande cs
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /cs pas encore implémentée.");
  },
};
