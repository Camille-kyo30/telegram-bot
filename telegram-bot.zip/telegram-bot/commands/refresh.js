module.exports = {
  config: {
    name: "refresh",
    aliases: [],
    description: "TODO : décrire la commande refresh",
    usage: "/refresh",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande refresh
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /refresh pas encore implémentée.");
  },
};
