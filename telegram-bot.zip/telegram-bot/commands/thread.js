module.exports = {
  config: {
    name: "thread",
    aliases: [],
    description: "TODO : décrire la commande thread",
    usage: "/thread",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande thread
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /thread pas encore implémentée.");
  },
};
