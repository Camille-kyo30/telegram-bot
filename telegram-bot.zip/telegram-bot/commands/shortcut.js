module.exports = {
  config: {
    name: "shortcut",
    aliases: [],
    description: "TODO : décrire la commande shortcut",
    usage: "/shortcut",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande shortcut
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /shortcut pas encore implémentée.");
  },
};
