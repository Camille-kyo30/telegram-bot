module.exports = {
  config: {
    name: "colony",
    aliases: [],
    description: "TODO : décrire la commande colony",
    usage: "/colony",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande colony
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /colony pas encore implémentée.");
  },
};
