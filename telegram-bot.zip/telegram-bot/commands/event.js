module.exports = {
  config: {
    name: "event",
    aliases: [],
    description: "TODO : décrire la commande event",
    usage: "/event",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande event
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /event pas encore implémentée.");
  },
};
