module.exports = {
  config: {
    name: "update",
    aliases: [],
    description: "TODO : décrire la commande update",
    usage: "/update",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande update
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /update pas encore implémentée.");
  },
};
