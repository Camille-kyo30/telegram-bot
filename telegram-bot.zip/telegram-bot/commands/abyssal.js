module.exports = {
  config: {
    name: "abyssal",
    aliases: [],
    description: "TODO : décrire la commande abyssal",
    usage: "/abyssal",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande abyssal
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /abyssal pas encore implémentée.");
  },
};
