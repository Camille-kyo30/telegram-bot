module.exports = {
  config: {
    name: "moon",
    aliases: [],
    description: "TODO : décrire la commande moon",
    usage: "/moon",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande moon
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /moon pas encore implémentée.");
  },
};
