module.exports = {
  config: {
    name: "texttoimage",
    aliases: [],
    description: "TODO : décrire la commande texttoimage",
    usage: "/texttoimage",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande texttoimage
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /texttoimage pas encore implémentée.");
  },
};
