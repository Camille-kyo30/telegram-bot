module.exports = {
  config: {
    name: "unsend",
    aliases: [],
    description: "TODO : décrire la commande unsend",
    usage: "/unsend",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande unsend
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /unsend pas encore implémentée.");
  },
};
