module.exports = {
  config: {
    name: "streets",
    aliases: [],
    description: "TODO : décrire la commande streets",
    usage: "/streets",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande streets
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /streets pas encore implémentée.");
  },
};
