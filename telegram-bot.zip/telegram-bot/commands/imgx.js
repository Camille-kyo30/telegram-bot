module.exports = {
  config: {
    name: "imgx",
    aliases: [],
    description: "TODO : décrire la commande imgx",
    usage: "/imgx",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande imgx
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /imgx pas encore implémentée.");
  },
};
