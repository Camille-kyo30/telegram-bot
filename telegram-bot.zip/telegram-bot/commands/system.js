module.exports = {
  config: {
    name: "system",
    aliases: [],
    description: "TODO : décrire la commande system",
    usage: "/system",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande system
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /system pas encore implémentée.");
  },
};
