module.exports = {
  config: {
    name: "filteruser",
    aliases: [],
    description: "TODO : décrire la commande filteruser",
    usage: "/filteruser",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande filteruser
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /filteruser pas encore implémentée.");
  },
};
