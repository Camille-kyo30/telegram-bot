module.exports = {
  config: {
    name: "tid",
    aliases: ["chatid"],
    description: "Affiche l'ID du chat/groupe actuel",
    usage: "/tid",
    ownerOnly: false,
  },
  async run(ctx) {
    ctx.reply(`💬 Chat ID : ${ctx.chat.id}`);
  },
};
