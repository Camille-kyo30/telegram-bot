module.exports = {
  config: {
    name: "Onlytik",
    aliases: [],
    description: "TODO : décrire la commande Onlytik",
    usage: "/Onlytik",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande Onlytik
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /Onlytik pas encore implémentée.");
  },
};
