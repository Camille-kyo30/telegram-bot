module.exports = {
  config: {
    name: "underworld",
    aliases: [],
    description: "TODO : décrire la commande underworld",
    usage: "/underworld",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande underworld
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /underworld pas encore implémentée.");
  },
};
