module.exports = {
  config: {
    name: "botnick",
    aliases: [],
    description: "TODO : décrire la commande botnick",
    usage: "/botnick",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande botnick
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /botnick pas encore implémentée.");
  },
};
