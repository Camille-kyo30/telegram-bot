module.exports = {
  config: {
    name: "noprefix",
    aliases: [],
    description: "TODO : décrire la commande noprefix",
    usage: "/noprefix",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande noprefix
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /noprefix pas encore implémentée.");
  },
};
