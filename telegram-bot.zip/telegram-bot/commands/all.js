module.exports = {
  config: {
    name: "all",
    aliases: [],
    description: "TODO : décrire la commande all",
    usage: "/all",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande all
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /all pas encore implémentée.");
  },
};
