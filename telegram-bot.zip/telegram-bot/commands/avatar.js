module.exports = {
  config: {
    name: "avatar",
    aliases: ["pp", "photo"],
    description: "Envoie ta photo de profil Telegram",
    usage: "/avatar",
    ownerOnly: false,
  },
  async run(ctx) {
    const photos = await ctx.telegram.getUserProfilePhotos(ctx.from.id, 0, 1);
    if (!photos.total_count) {
      return ctx.reply("❌ Tu n'as pas de photo de profil visible.");
    }
    const fileId = photos.photos[0][photos.photos[0].length - 1].file_id;
    ctx.replyWithPhoto(fileId);
  },
};
