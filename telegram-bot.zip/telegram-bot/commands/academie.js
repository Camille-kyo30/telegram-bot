module.exports = {
  config: {
    name: "academie",
    aliases: [],
    description: "TODO : décrire la commande academie",
    usage: "/academie",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande academie
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /academie pas encore implémentée.");
  },
};
