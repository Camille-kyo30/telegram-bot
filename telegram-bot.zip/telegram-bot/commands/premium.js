module.exports = {
  config: {
    name: "premium",
    aliases: [],
    description: "TODO : décrire la commande premium",
    usage: "/premium",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande premium
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /premium pas encore implémentée.");
  },
};
