module.exports = {
  config: {
    name: "autoaccept",
    aliases: [],
    description: "TODO : décrire la commande autoaccept",
    usage: "/autoaccept",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande autoaccept
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /autoaccept pas encore implémentée.");
  },
};
