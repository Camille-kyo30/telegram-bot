const { isChatAdmin } = require("../utils/permissions");
const { readDb, writeDb } = require("../utils/db");

module.exports = {
  config: {
    name: "rules",
    aliases: ["regles"],
    description: "Affiche ou définit le règlement du groupe",
    usage: "/rules [set <texte>]",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    const db = readDb();
    const chatId = String(ctx.chat.id);

    if ((args[0] || "").toLowerCase() === "set") {
      if (ctx.chat.type === "private") {
        return ctx.reply("⚠️ Commande utilisable seulement dans un groupe.");
      }
      if (!(await isChatAdmin(ctx))) {
        return ctx.reply("⛔ Réservé aux admins du groupe.");
      }
      const text = args.slice(1).join(" ");
      if (!text) return ctx.reply("⚠️ Usage : /rules set <texte>");
      db.rules[chatId] = text;
      writeDb(db);
      return ctx.reply("✅ Règlement mis à jour.");
    }

    const rules = db.rules[chatId];
    ctx.reply(
      rules
        ? `📜 Règlement du groupe :\n\n${rules}`
        : "Aucun règlement défini pour l'instant. (Un admin peut faire /rules set <texte>)"
    );
  },
};
