module.exports = {
  config: {
    name: "gay",
    aliases: [],
    description: "TODO : décrire la commande gay",
    usage: "/gay",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande gay
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /gay pas encore implémentée.");
  },
};
