const { isChatAdmin } = require("../utils/permissions");
const { readDb, writeDb } = require("../utils/db");

module.exports = {
  config: {
    name: "badwords",
    aliases: [],
    description: "Gère la liste de mots interdits (suppression auto des messages)",
    usage: "/badwords <add|remove|list|on|off> [mot]",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    if (ctx.chat.type === "private") {
      return ctx.reply("⚠️ Commande utilisable seulement dans un groupe.");
    }
    if (!(await isChatAdmin(ctx))) {
      return ctx.reply("⛔ Réservé aux admins du groupe.");
    }

    const db = readDb();
    const chatId = String(ctx.chat.id);
    db.badwords[chatId] = db.badwords[chatId] || [];

    const sub = (args[0] || "").toLowerCase();
    const word = args.slice(1).join(" ").toLowerCase();

    switch (sub) {
      case "add":
        if (!word) return ctx.reply("⚠️ Usage : /badwords add <mot>");
        if (!db.badwords[chatId].includes(word)) db.badwords[chatId].push(word);
        writeDb(db);
        return ctx.reply(`✅ "${word}" ajouté à la liste des mots interdits.`);

      case "remove":
        db.badwords[chatId] = db.badwords[chatId].filter((w) => w !== word);
        writeDb(db);
        return ctx.reply(`🗑️ "${word}" retiré de la liste.`);

      case "list":
        return ctx.reply(
          db.badwords[chatId].length
            ? `📋 Mots interdits :\n${db.badwords[chatId].join(", ")}`
            : "Aucun mot interdit configuré."
        );

      case "on":
        db.badwordsEnabled[chatId] = true;
        writeDb(db);
        return ctx.reply("🛡️ Filtre de mots interdits activé (suppression automatique).");

      case "off":
        db.badwordsEnabled[chatId] = false;
        writeDb(db);
        return ctx.reply("🛡️ Filtre de mots interdits désactivé.");

      default:
        return ctx.reply("⚠️ Usage : /badwords <add|remove|list|on|off> [mot]");
    }
  },
};
