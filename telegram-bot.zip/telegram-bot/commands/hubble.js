module.exports = {
  config: {
    name: "hubble",
    aliases: [],
    description: "TODO : décrire la commande hubble",
    usage: "/hubble",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande hubble
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /hubble pas encore implémentée.");
  },
};
