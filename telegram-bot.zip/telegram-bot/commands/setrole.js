const { isChatAdmin, getTargetUser } = require("../utils/permissions");
const { readDb, writeDb } = require("../utils/db");

const VALID_ROLES = ["admin", "vip", "member"];

module.exports = {
  config: {
    name: "setrole",
    aliases: [],
    description: "Attribue un rôle interne au bot à un utilisateur (admin/vip/member)",
    usage: "/setrole <admin|vip|member> (en réponse à un message)",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    if (ctx.chat.type === "private") {
      return ctx.reply("⚠️ Commande utilisable seulement dans un groupe.");
    }
    if (!(await isChatAdmin(ctx))) {
      return ctx.reply("⛔ Réservé aux admins du groupe.");
    }

    const role = (args[0] || "").toLowerCase();
    if (!VALID_ROLES.includes(role)) {
      return ctx.reply(`⚠️ Usage : /setrole <${VALID_ROLES.join("|")}> (en réponse à un message)`);
    }

    const target = getTargetUser(ctx);
    if (!target) return ctx.reply("⚠️ Réponds au message de la personne concernée.");

    const db = readDb();
    const chatId = String(ctx.chat.id);
    db.roles[chatId] = db.roles[chatId] || {};
    db.roles[chatId][String(target.id)] = role;
    writeDb(db);

    ctx.reply(`✅ Rôle "${role}" attribué à ${target.first_name || target.id}.`);
  },
};
