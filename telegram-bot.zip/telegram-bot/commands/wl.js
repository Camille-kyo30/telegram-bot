module.exports = {
  config: {
    name: "wl",
    aliases: [],
    description: "TODO : décrire la commande wl",
    usage: "/wl",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande wl
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /wl pas encore implémentée.");
  },
};
