module.exports = {
  config: {
    name: "wheel",
    aliases: [],
    description: "TODO : décrire la commande wheel",
    usage: "/wheel",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande wheel
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /wheel pas encore implémentée.");
  },
};
