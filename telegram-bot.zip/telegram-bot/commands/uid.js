module.exports = {
  config: {
    name: "uid",
    aliases: [],
    description: "Affiche ton ID Telegram, ou celui d'un message cité",
    usage: "/uid (en réponse à un message, optionnel)",
    ownerOnly: false,
  },
  async run(ctx) {
    const target = ctx.message.reply_to_message?.from || ctx.from;
    const name = target.first_name || target.username || "Utilisateur";
    ctx.reply(`🆔 ${name} : ${target.id}`);
  },
};
