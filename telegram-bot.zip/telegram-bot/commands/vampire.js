module.exports = {
  config: {
    name: "vampire",
    aliases: [],
    description: "TODO : décrire la commande vampire",
    usage: "/vampire",
    ownerOnly: false,
  },
  async run(ctx, { args }) {
    // TODO : implémenter la logique de la commande vampire
    // (portée depuis CHRISTUS-GOATBOT-PUBLIC, contenu original non repris ici)
    ctx.reply("🚧 Commande /vampire pas encore implémentée.");
  },
};
