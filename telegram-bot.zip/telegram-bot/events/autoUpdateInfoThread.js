module.exports = {
  config: {
    name: "autoUpdateInfoThread",
    type: "any",
  },
  async run(ctx) {
    // TODO : mettre à jour en base le titre/photo/membres du groupe à chaque update
    // (portée depuis autoUpdateInfoThread.js de GoatBot)
  },
};
