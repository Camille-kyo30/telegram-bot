module.exports = {
  config: {
    name: "logsbot",
    type: "any",
  },
  async run(ctx) {
    // TODO : journaliser les updates (messages, commandes) vers un canal owner ou un fichier
    // (portée depuis logsbot.js de GoatBot)
    if (ctx.message) {
      console.log(
        `[logsbot] chat=${ctx.chat.id} user=${ctx.from?.id} text="${ctx.message.text || ""}"`
      );
    }
  },
};
