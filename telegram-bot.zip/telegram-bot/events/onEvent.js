const { readDb } = require("../utils/db");

module.exports = {
  config: {
    name: "onEvent",
    type: "any",
  },
  async run(ctx) {
    if (!ctx.message || !ctx.message.text) return;

    const db = readDb();
    const chatId = String(ctx.chat.id);
    if (!db.badwordsEnabled[chatId]) return;

    const words = db.badwords[chatId] || [];
    if (!words.length) return;

    const text = ctx.message.text.toLowerCase();
    const hit = words.find((w) => text.includes(w));
    if (!hit) return;

    try {
      await ctx.deleteMessage();
      const name = ctx.from.first_name || ctx.from.username || "quelqu'un";
      await ctx.reply(`🚫 Message de ${name} supprimé (mot interdit).`);
    } catch {
      // Le bot n'a probablement pas les droits admin nécessaires pour supprimer.
    }
  },
};
