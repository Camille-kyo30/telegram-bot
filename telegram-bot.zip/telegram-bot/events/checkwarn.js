module.exports = {
  config: {
    name: "checkwarn",
    type: "any",
  },
  async run(ctx) {
    // TODO : implémenter la logique de vérification des warns par utilisateur
    // (portée depuis checkwarn.js de GoatBot, ex: ban auto après N warns)
  },
};
