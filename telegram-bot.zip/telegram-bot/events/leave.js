module.exports = {
  config: {
    name: "leave",
    type: "left_chat_member",
  },
  async run(ctx) {
    // TODO : personnaliser le message (portée depuis setleave.js / leave.js de GoatBot)
    const member = ctx.message.left_chat_member;
    if (!member) return;
    const displayName = member.first_name || member.username || "un membre";
    ctx.reply(`👋 ${displayName} a quitté le groupe.`);
  },
};
