module.exports = {
  config: {
    name: "welcome",
    type: "new_chat_members",
  },
  async run(ctx) {
    // TODO : personnaliser le message (portée depuis setwelcome.js / welcome.js de GoatBot)
    const newMembers = ctx.message.new_chat_members || [];
    for (const member of newMembers) {
      const displayName = member.first_name || member.username || "nouveau membre";
      ctx.reply(`🍓━━━━━━━━🍓\n👋 Bienvenue ${displayName} !\n🍓━━━━━━━━🍓`);
    }
  },
};
