// Fichier exemple — les fichiers *.eg.js ne sont PAS chargés par eventLoader.
// Copie ce fichier sous un nouveau nom (ex: monevent.js) pour créer un event.
module.exports = {
  config: {
    name: "nomdelevent",
    type: "any", // ou "new_chat_members" / "left_chat_member"
  },
  async run(ctx) {
    // Logique de l'event ici
  },
};
